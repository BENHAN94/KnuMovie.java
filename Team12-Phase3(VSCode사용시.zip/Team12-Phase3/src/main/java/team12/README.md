# 수정사항

1.
scanNextInt() 모두 정상작동 합니다. 
</br>
*참고: catchScanNextInt() 내용 수정

2.
영화 검색 또는 평가 내역 검색 시
</br>
메뉴에 "1. 다음" 이 표시되지 않을 때 (더 표시할 항목이 없을 때) 1을 누르는 경우
</br>
수정 이전에는 빈 화면이 출력되었습니다.
</br>
=> 아무런 반응이 없도록 수정했습니다. ("2.이전" 도 마찬가지)
</br>
*참고: queryMovie(), showRatingLog();

# TODO

1. 버그 체크
</br>
2. README.txt 작성

    
